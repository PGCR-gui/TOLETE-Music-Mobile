package com.tolete.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tolete.player.data.Track

private data class GroupItem(val title: String, val subtitle: String, val key: String)

private fun faixas(n: Int) = if (n == 1) "1 faixa" else "$n faixas"

private fun formatDuration(ms: Long): String {
    val total = ms / 1000
    return "%d:%02d".format(total / 60, total % 60)
}

@Composable
fun TolereApp(vm: MusicViewModel, onPickFolder: () -> Unit) {
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    val isScanning by vm.isScanning.collectAsStateWithLifecycle()
    val tab by vm.currentTab.collectAsStateWithLifecycle()
    val filter by vm.filter.collectAsStateWithLifecycle()
    val visible by vm.visibleTracks.collectAsStateWithLifecycle()
    val nowPlaying by vm.nowPlaying.collectAsStateWithLifecycle()
    val isPlaying by vm.isPlaying.collectAsStateWithLifecycle()
    val artists by vm.artists.collectAsStateWithLifecycle()
    val albums by vm.albums.collectAsStateWithLifecycle()
    val genres by vm.genres.collectAsStateWithLifecycle()
    val folders by vm.folders.collectAsStateWithLifecycle()

    BackHandler(enabled = filter != null) { vm.clearFilter() }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.Transparent,
        contentColor = Color.White
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(listOf(Color(0xFF241440), Color(0xFF0B0B14)))
                )
        ) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {

                Header(
                    title = filter?.key ?: "Tolete Music",
                    showBack = filter != null,
                    onBack = vm::clearFilter,
                    onPickFolder = onPickFolder
                )

                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when {
                        isScanning -> Column(
                            Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            CircularProgressIndicator()
                            Text("Lendo sua biblioteca…", modifier = Modifier.padding(top = 16.dp))
                        }

                        tracks.isEmpty() -> Column(
                            Modifier.fillMaxSize().padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text("Nenhuma música ainda", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                "Escolha a pasta onde estão suas músicas.",
                                modifier = Modifier.padding(vertical = 12.dp),
                                color = Color.White.copy(alpha = 0.7f)
                            )
                            Button(onClick = onPickFolder) { Text("Escolher pasta") }
                        }

                        filter != null -> TrackList(
                            tracks = visible,
                            nowPlayingId = nowPlaying?.id,
                            onClick = { index -> vm.playTracks(visible, index) }
                        )

                        else -> {
                            val groups = when (tab) {
                                MusicViewModel.Tab.ARTISTS ->
                                    artists.map { GroupItem(it.name, faixas(it.trackCount), it.name) }
                                MusicViewModel.Tab.ALBUMS ->
                                    albums.map { GroupItem(it.name, "${it.artist} · ${faixas(it.trackCount)}", it.name) }
                                MusicViewModel.Tab.GENRES ->
                                    genres.map { GroupItem(it.name, faixas(it.trackCount), it.name) }
                                MusicViewModel.Tab.FOLDERS ->
                                    folders.map { GroupItem(it.name, faixas(it.trackCount), it.name) }
                            }
                            GroupList(groups, onClick = vm::openGroup)
                        }
                    }
                }

                nowPlaying?.let {
                    MiniPlayer(
                        track = it,
                        isPlaying = isPlaying,
                        onPrevious = vm::previous,
                        onToggle = vm::togglePlayPause,
                        onNext = vm::next
                    )
                }

                LiquidGlassNavigation(
                    currentTab = tab,
                    onTabSelected = vm::setTab
                )
            }
        }
    }
}

@Composable
private fun Header(
    title: String,
    showBack: Boolean,
    onBack: () -> Unit,
    onPickFolder: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (showBack) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Voltar")
            }
        }
        Text(
            text = title,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(start = if (showBack) 0.dp else 12.dp)
        )
        IconButton(onClick = onPickFolder) {
            Icon(Icons.Rounded.FolderOpen, contentDescription = "Escolher pasta")
        }
    }
}

@Composable
private fun GroupList(items: List<GroupItem>, onClick: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
        items(items) { item ->
            Column(
                Modifier
                    .fillMaxWidth()
                    .clickable { onClick(item.key) }
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(item.title, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    item.subtitle,
                    fontSize = 13.sp,
                    color = Color.White.copy(alpha = 0.6f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun TrackList(tracks: List<Track>, nowPlayingId: String?, onClick: (Int) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
        itemsIndexed(tracks) { index, track ->
            val active = track.id == nowPlayingId
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onClick(index) }
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        track.title,
                        fontSize = 16.sp,
                        color = if (active) MaterialTheme.colorScheme.primary else Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "${track.artist} · ${track.album}",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.6f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    formatDuration(track.duration),
                    fontSize = 13.sp,
                    color = Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.padding(start = 12.dp)
                )
            }
        }
    }
}

@Composable
private fun MiniPlayer(
    track: Track,
    isPlaying: Boolean,
    onPrevious: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(alpha = 0.12f))
            .padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(track.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onPrevious) { Icon(Icons.Rounded.SkipPrevious, contentDescription = "Anterior") }
        IconButton(onClick = onToggle) {
            Icon(
                if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = if (isPlaying) "Pausar" else "Tocar"
            )
        }
        IconButton(onClick = onNext) { Icon(Icons.Rounded.SkipNext, contentDescription = "Próxima") }
    }
}
