package com.tolete.player.data

import android.net.Uri

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val genre: String,
    val duration: Long,          // em milissegundos
    val uri: Uri,
    val path: String,
    val folder: String,
    val year: Int? = null,
    val trackNumber: Int? = null
)

data class Artist(
    val name: String,
    val trackCount: Int
)

data class Album(
    val name: String,
    val artist: String,
    val trackCount: Int,
    val year: Int? = null
)

data class Genre(
    val name: String,
    val trackCount: Int
)

data class Folder(
    val name: String,
    val path: String,
    val trackCount: Int
)