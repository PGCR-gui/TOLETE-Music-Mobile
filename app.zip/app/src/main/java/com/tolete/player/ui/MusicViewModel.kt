package com.tolete.player.ui

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.tolete.player.PlaybackService
import com.tolete.player.data.Album
import com.tolete.player.data.Artist
import com.tolete.player.data.Folder
import com.tolete.player.data.Genre
import com.tolete.player.data.MusicScanner
import com.tolete.player.data.Track
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MusicViewModel(application: Application) : AndroidViewModel(application) {

    // ---------- Abas e filtro ----------
    enum class Tab { ARTISTS, ALBUMS, GENRES, FOLDERS }

    /** Grupo aberto (ex.: um artista específico). null = mostrando a lista de grupos. */
    data class Filter(val tab: Tab, val key: String)

    private val scanner = MusicScanner(application)
    private val prefs = application.getSharedPreferences("tolete", Context.MODE_PRIVATE)

    private val _tracks = MutableStateFlow<List<Track>>(emptyList())
    val tracks: StateFlow<List<Track>> = _tracks.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _currentTab = MutableStateFlow(Tab.ARTISTS)
    val currentTab: StateFlow<Tab> = _currentTab.asStateFlow()

    private val _filter = MutableStateFlow<Filter?>(null)
    val filter: StateFlow<Filter?> = _filter.asStateFlow()

    fun setTab(tab: Tab) {
        _currentTab.value = tab
        _filter.value = null
    }

    fun openGroup(key: String) {
        _filter.value = Filter(_currentTab.value, key)
    }

    fun clearFilter() {
        _filter.value = null
    }

    // ---------- Agrupamentos (derivados de tracks) ----------
    val artists: StateFlow<List<Artist>> = tracks.map { list ->
        list.groupBy { it.artist }
            .map { (name, l) -> Artist(name, l.size) }
            .sortedBy { it.name.lowercase() }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val albums: StateFlow<List<Album>> = tracks.map { list ->
        list.groupBy { it.album to it.artist }
            .map { (key, l) -> Album(key.first, key.second, l.size, l.firstOrNull()?.year) }
            .sortedBy { it.name.lowercase() }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val genres: StateFlow<List<Genre>> = tracks.map { list ->
        list.groupBy { it.genre }
            .map { (name, l) -> Genre(name, l.size) }
            .sortedBy { it.name.lowercase() }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val folders: StateFlow<List<Folder>> = tracks.map { list ->
        list.groupBy { it.folder }
            .map { (name, l) -> Folder(name, name, l.size) }
            .sortedBy { it.name.lowercase() }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Faixas do grupo aberto, ordenadas por álbum > nº da faixa > título. */
    val visibleTracks: StateFlow<List<Track>> = combine(tracks, filter) { list, f ->
        val base = if (f == null) list else list.filter {
            when (f.tab) {
                Tab.ARTISTS -> it.artist == f.key
                Tab.ALBUMS -> it.album == f.key
                Tab.GENRES -> it.genre == f.key
                Tab.FOLDERS -> it.folder == f.key
            }
        }
        base.sortedWith(
            compareBy<Track>({ it.album.lowercase() }, { it.trackNumber ?: Int.MAX_VALUE }, { it.title.lowercase() })
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---------- Scan ----------
    fun scanFolder(treeUri: Uri) {
        prefs.edit().putString(KEY_TREE_URI, treeUri.toString()).apply()
        viewModelScope.launch {
            _isScanning.value = true
            try {
                _tracks.value = scanner.scanTree(treeUri)
            } catch (e: Exception) {
                _tracks.value = emptyList()
            } finally {
                _isScanning.value = false
            }
        }
    }

    // ---------- Player (MediaController -> PlaybackService) ----------
    private val _nowPlaying = MutableStateFlow<Track?>(null)
    val nowPlaying: StateFlow<Track?> = _nowPlaying.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private var queue: List<Track> = emptyList()
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.value = isPlaying
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            _nowPlaying.value = queue.firstOrNull { it.id == mediaItem?.mediaId }
        }
    }

    private fun connectController() {
        val app = getApplication<Application>()
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                controller = future.get().also { it.addListener(playerListener) }
            } catch (e: Exception) {
                controller = null
            }
        }, ContextCompat.getMainExecutor(app))
    }

    fun playTracks(list: List<Track>, startIndex: Int) {
        val c = controller ?: return
        if (startIndex !in list.indices) return
        queue = list
        c.setMediaItems(list.map { it.toMediaItem() }, startIndex, 0L)
        c.prepare()
        c.play()
        _nowPlaying.value = list[startIndex]
    }

    fun togglePlayPause() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        controller?.seekToPreviousMediaItem()
    }

    private fun Track.toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .build()
        )
        .build()

    init {
        connectController()

        // Reabre a última pasta escolhida, se a permissão ainda existir
        prefs.getString(KEY_TREE_URI, null)?.let { saved ->
            val uri = Uri.parse(saved)
            val hasPermission = application.contentResolver.persistedUriPermissions
                .any { it.uri == uri && it.isReadPermission }
            if (hasPermission) scanFolder(uri)
        }
    }

    override fun onCleared() {
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onCleared()
    }

    private companion object {
        const val KEY_TREE_URI = "tree_uri"
    }
}
