package com.tolete.player.data

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

class MusicScanner(private val context: Context) {

    private val supportedExtensions = setOf(
        "mp3", "flac", "m4a", "aac", "ogg", "opus", "wav", "wma", "aiff", "alac"
    )

    suspend fun scanTree(treeUri: Uri): List<Track> = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<Track>()
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(
            treeUri,
            DocumentsContract.getTreeDocumentId(treeUri)
        )

        scanRecursive(childrenUri, treeUri, tracks)
        tracks
    }

    private fun scanRecursive(childrenUri: Uri, treeUri: Uri, tracks: MutableList<Track>) {
        context.contentResolver.query(
            childrenUri,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE
            ),
            null, null, null
        )?.use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameIndex = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeIndex = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)

            while (cursor.moveToNext()) {
                val docId = cursor.getString(idIndex)
                val name = cursor.getString(nameIndex)
                val mime = cursor.getString(mimeIndex)

                val documentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)

                if (DocumentsContract.Document.MIME_TYPE_DIR == mime) {
                    // É pasta → continua recursivamente
                    val childUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
                    scanRecursive(childUri, treeUri, tracks)
                } else {
                    // É arquivo → verifica extensão
                    val extension = name.substringAfterLast('.', "").lowercase()
                    if (extension in supportedExtensions) {
                        extractMetadata(documentUri, name)?.let { tracks.add(it) }
                    }
                }
            }
        }
    }

    private fun extractMetadata(uri: Uri, fileName: String): Track? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)

            val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                ?: fileName.substringBeforeLast('.')
            val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: "Desconhecido"
            val album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: "Desconhecido"
            val genre = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE) ?: "Desconhecido"
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val year = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR)?.toIntOrNull()
            val trackNumber = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER)?.toIntOrNull()

            // Pasta aproximada
            val folder = uri.path?.substringBeforeLast('/')?.substringAfterLast('/') ?: "Raiz"

            Track(
                id = UUID.randomUUID().toString(),
                title = title,
                artist = artist,
                album = album,
                genre = genre,
                duration = duration,
                uri = uri,
                path = fileName,
                folder = folder,
                year = year,
                trackNumber = trackNumber
            )
        } catch (e: Exception) {
            null
        } finally {
            retriever.release()
        }
    }
}